from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate
from config import Config

db = SQLAlchemy()
migrate = Migrate()


def create_app(config_class=Config):
    app = Flask(__name__)
    app.config.from_object(config_class)

    db.init_app(app)
    migrate.init_app(app, db)

    from app.routes.main import main_bp
    from app.routes.customers import customers_bp
    from app.routes.campaigns import campaigns_bp
    from app.routes.predictions import predictions_bp
    from app.routes.analytics import analytics_bp

    app.register_blueprint(main_bp)
    app.register_blueprint(customers_bp, url_prefix="/customers")
    app.register_blueprint(campaigns_bp, url_prefix="/campaigns")
    app.register_blueprint(predictions_bp, url_prefix="/predictions")
    app.register_blueprint(analytics_bp, url_prefix="/analytics")

    return app
