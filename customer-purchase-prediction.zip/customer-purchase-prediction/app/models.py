from datetime import datetime
from app import db


class Customer(db.Model):
    __tablename__ = "customers"

    id = db.Column(db.Integer, primary_key=True)
    customer_id = db.Column(db.String(50), unique=True, nullable=False)
    age = db.Column(db.Integer)
    gender = db.Column(db.String(10))
    income = db.Column(db.Float)
    location = db.Column(db.String(100))
    segment = db.Column(db.String(50))          # e.g. High Value, At Risk, New
    registration_date = db.Column(db.DateTime, default=datetime.utcnow)

    purchases = db.relationship("Purchase", backref="customer", lazy=True)
    campaign_responses = db.relationship("CampaignResponse", backref="customer", lazy=True)

    def to_dict(self):
        return {
            "id": self.id,
            "customer_id": self.customer_id,
            "age": self.age,
            "gender": self.gender,
            "income": self.income,
            "location": self.location,
            "segment": self.segment,
            "registration_date": self.registration_date.isoformat() if self.registration_date else None,
        }


class Purchase(db.Model):
    __tablename__ = "purchases"

    id = db.Column(db.Integer, primary_key=True)
    customer_id = db.Column(db.Integer, db.ForeignKey("customers.id"), nullable=False)
    product_category = db.Column(db.String(100))
    amount = db.Column(db.Float, nullable=False)
    purchase_date = db.Column(db.DateTime, default=datetime.utcnow)
    channel = db.Column(db.String(50))          # online / in-store / mobile

    def to_dict(self):
        return {
            "id": self.id,
            "customer_id": self.customer_id,
            "product_category": self.product_category,
            "amount": self.amount,
            "purchase_date": self.purchase_date.isoformat() if self.purchase_date else None,
            "channel": self.channel,
        }


class Campaign(db.Model):
    __tablename__ = "campaigns"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(200), nullable=False)
    type = db.Column(db.String(50))             # email / sms / push / display
    start_date = db.Column(db.DateTime)
    end_date = db.Column(db.DateTime)
    budget = db.Column(db.Float)
    target_segment = db.Column(db.String(50))
    status = db.Column(db.String(20), default="active")

    responses = db.relationship("CampaignResponse", backref="campaign", lazy=True)

    @property
    def total_responses(self):
        return len(self.responses)

    @property
    def conversion_rate(self):
        if not self.responses:
            return 0.0
        converted = sum(1 for r in self.responses if r.converted)
        return round(converted / len(self.responses) * 100, 2)

    def to_dict(self):
        return {
            "id": self.id,
            "name": self.name,
            "type": self.type,
            "start_date": self.start_date.isoformat() if self.start_date else None,
            "end_date": self.end_date.isoformat() if self.end_date else None,
            "budget": self.budget,
            "target_segment": self.target_segment,
            "status": self.status,
            "total_responses": self.total_responses,
            "conversion_rate": self.conversion_rate,
        }


class CampaignResponse(db.Model):
    __tablename__ = "campaign_responses"

    id = db.Column(db.Integer, primary_key=True)
    campaign_id = db.Column(db.Integer, db.ForeignKey("campaigns.id"), nullable=False)
    customer_id = db.Column(db.Integer, db.ForeignKey("customers.id"), nullable=False)
    response_date = db.Column(db.DateTime, default=datetime.utcnow)
    converted = db.Column(db.Boolean, default=False)
    revenue_generated = db.Column(db.Float, default=0.0)

    def to_dict(self):
        return {
            "id": self.id,
            "campaign_id": self.campaign_id,
            "customer_id": self.customer_id,
            "response_date": self.response_date.isoformat() if self.response_date else None,
            "converted": self.converted,
            "revenue_generated": self.revenue_generated,
        }


class PredictionLog(db.Model):
    __tablename__ = "prediction_logs"

    id = db.Column(db.Integer, primary_key=True)
    customer_id = db.Column(db.Integer, db.ForeignKey("customers.id"), nullable=False)
    model_version = db.Column(db.String(50))
    purchase_probability = db.Column(db.Float)
    predicted_segment = db.Column(db.String(50))
    prediction_date = db.Column(db.DateTime, default=datetime.utcnow)
    features_used = db.Column(db.Text)          # JSON-serialised feature snapshot

    def to_dict(self):
        return {
            "id": self.id,
            "customer_id": self.customer_id,
            "model_version": self.model_version,
            "purchase_probability": self.purchase_probability,
            "predicted_segment": self.predicted_segment,
            "prediction_date": self.prediction_date.isoformat() if self.prediction_date else None,
        }
