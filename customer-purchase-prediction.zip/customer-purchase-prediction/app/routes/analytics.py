from flask import Blueprint, render_template, jsonify
from app.models import Customer, Purchase, Campaign, CampaignResponse
from app import db
from sqlalchemy import func
import json

analytics_bp = Blueprint("analytics", __name__)


@analytics_bp.route("/")
def analytics_home():
    return render_template("analytics/index.html")


@analytics_bp.route("/api/revenue-trend")
def revenue_trend():
    results = db.session.query(
        func.year(Purchase.purchase_date).label("year"),
        func.month(Purchase.purchase_date).label("month"),
        func.sum(Purchase.amount).label("revenue"),
        func.count(Purchase.id).label("transactions"),
    ).group_by("year", "month").order_by("year", "month").all()

    return jsonify([
        {
            "period": f"{r.year}-{str(r.month).zfill(2)}",
            "revenue": round(float(r.revenue or 0), 2),
            "transactions": r.transactions,
        }
        for r in results
    ])


@analytics_bp.route("/api/channel-breakdown")
def channel_breakdown():
    results = db.session.query(
        Purchase.channel,
        func.count(Purchase.id).label("count"),
        func.sum(Purchase.amount).label("revenue"),
    ).group_by(Purchase.channel).all()

    return jsonify([
        {"channel": r.channel, "count": r.count, "revenue": round(float(r.revenue or 0), 2)}
        for r in results
    ])


@analytics_bp.route("/api/category-performance")
def category_performance():
    results = db.session.query(
        Purchase.product_category,
        func.count(Purchase.id).label("count"),
        func.sum(Purchase.amount).label("revenue"),
        func.avg(Purchase.amount).label("avg_order"),
    ).group_by(Purchase.product_category)\
     .order_by(func.sum(Purchase.amount).desc()).limit(10).all()

    return jsonify([
        {
            "category": r.product_category,
            "count": r.count,
            "revenue": round(float(r.revenue or 0), 2),
            "avg_order": round(float(r.avg_order or 0), 2),
        }
        for r in results
    ])


@analytics_bp.route("/api/segment-revenue")
def segment_revenue():
    results = db.session.query(
        Customer.segment,
        func.count(Customer.id).label("customers"),
        func.sum(Purchase.amount).label("revenue"),
    ).join(Purchase).group_by(Customer.segment).all()

    return jsonify([
        {
            "segment": r.segment,
            "customers": r.customers,
            "revenue": round(float(r.revenue or 0), 2),
        }
        for r in results
    ])


@analytics_bp.route("/api/campaign-funnel")
def campaign_funnel():
    campaigns = Campaign.query.all()
    funnel = []
    for c in campaigns:
        total = len(c.responses)
        converted = sum(1 for r in c.responses if r.converted)
        revenue = sum(r.revenue_generated for r in c.responses)
        funnel.append({
            "campaign": c.name,
            "reached": total,
            "converted": converted,
            "revenue": round(revenue, 2),
            "conversion_rate": round(converted / total * 100, 2) if total else 0,
        })
    return jsonify(funnel)
