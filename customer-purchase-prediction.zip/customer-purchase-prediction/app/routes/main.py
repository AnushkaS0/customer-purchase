from flask import Blueprint, render_template
from app.models import Customer, Campaign, Purchase, CampaignResponse
from app import db
from sqlalchemy import func

main_bp = Blueprint("main", __name__)


@main_bp.route("/")
def index():
    # KPI summary cards
    total_customers = Customer.query.count()
    total_campaigns = Campaign.query.count()
    total_revenue = db.session.query(func.sum(Purchase.amount)).scalar() or 0
    avg_conversion = db.session.query(func.avg(
        db.case((CampaignResponse.converted == True, 1), else_=0)
    )).scalar() or 0

    stats = {
        "total_customers": total_customers,
        "total_campaigns": total_campaigns,
        "total_revenue": round(total_revenue, 2),
        "avg_conversion_rate": round(float(avg_conversion) * 100, 2),
    }
    return render_template("index.html", stats=stats)


@main_bp.route("/dashboard")
def dashboard():
    return render_template("dashboard.html")


@main_bp.errorhandler(404)
def not_found(e):
    return render_template("404.html"), 404


@main_bp.errorhandler(500)
def server_error(e):
    return render_template("500.html"), 500
