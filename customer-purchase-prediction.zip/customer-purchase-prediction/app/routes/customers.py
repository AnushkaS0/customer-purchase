from flask import Blueprint, render_template, request, jsonify
from app.models import Customer, Purchase
from app import db
from sqlalchemy import func

customers_bp = Blueprint("customers", __name__)


@customers_bp.route("/")
def list_customers():
    page = request.args.get("page", 1, type=int)
    segment = request.args.get("segment")
    query = Customer.query
    if segment:
        query = query.filter_by(segment=segment)
    customers = query.paginate(page=page, per_page=20, error_out=False)
    return render_template("customers/list.html", customers=customers)


@customers_bp.route("/<int:customer_id>")
def customer_detail(customer_id):
    customer = Customer.query.get_or_404(customer_id)
    purchases = Purchase.query.filter_by(customer_id=customer_id)\
        .order_by(Purchase.purchase_date.desc()).limit(10).all()
    total_spent = db.session.query(func.sum(Purchase.amount))\
        .filter_by(customer_id=customer_id).scalar() or 0
    return render_template(
        "customers/detail.html",
        customer=customer,
        purchases=purchases,
        total_spent=round(total_spent, 2),
    )


@customers_bp.route("/api/segments")
def segment_distribution():
    results = db.session.query(
        Customer.segment, func.count(Customer.id).label("count")
    ).group_by(Customer.segment).all()
    return jsonify([{"segment": r.segment, "count": r.count} for r in results])


@customers_bp.route("/api/list")
def api_list():
    customers = Customer.query.limit(100).all()
    return jsonify([c.to_dict() for c in customers])
