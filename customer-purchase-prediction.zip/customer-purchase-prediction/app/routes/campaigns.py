from flask import Blueprint, render_template, request, jsonify
from app.models import Campaign, CampaignResponse
from app import db
from sqlalchemy import func

campaigns_bp = Blueprint("campaigns", __name__)


@campaigns_bp.route("/")
def list_campaigns():
    campaigns = Campaign.query.order_by(Campaign.start_date.desc()).all()
    return render_template("campaigns/list.html", campaigns=campaigns)


@campaigns_bp.route("/<int:campaign_id>")
def campaign_detail(campaign_id):
    campaign = Campaign.query.get_or_404(campaign_id)
    responses = CampaignResponse.query.filter_by(campaign_id=campaign_id).all()
    daily_responses = db.session.query(
        func.date(CampaignResponse.response_date).label("date"),
        func.count(CampaignResponse.id).label("count"),
        func.sum(db.case((CampaignResponse.converted == True, 1), else_=0)).label("converted"),
    ).filter_by(campaign_id=campaign_id)\
     .group_by(func.date(CampaignResponse.response_date)).all()

    return render_template(
        "campaigns/detail.html",
        campaign=campaign,
        responses=responses,
        daily_responses=daily_responses,
    )


@campaigns_bp.route("/api/performance")
def campaign_performance():
    campaigns = Campaign.query.all()
    return jsonify([c.to_dict() for c in campaigns])


@campaigns_bp.route("/api/roi")
def campaign_roi():
    results = db.session.query(
        Campaign.name,
        Campaign.budget,
        func.sum(CampaignResponse.revenue_generated).label("revenue"),
    ).join(CampaignResponse).group_by(Campaign.id, Campaign.name, Campaign.budget).all()

    data = []
    for r in results:
        roi = ((r.revenue - r.budget) / r.budget * 100) if r.budget else 0
        data.append({"campaign": r.name, "budget": r.budget, "revenue": r.revenue, "roi": round(roi, 2)})
    return jsonify(data)
