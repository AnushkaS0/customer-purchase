from flask import Blueprint, render_template, request, jsonify
from app.models import Customer, PredictionLog
from app import db
from ml_models.predictor import PurchasePredictor
import json

predictions_bp = Blueprint("predictions", __name__)
predictor = PurchasePredictor()


@predictions_bp.route("/")
def predictions_home():
    recent = PredictionLog.query.order_by(PredictionLog.prediction_date.desc()).limit(20).all()
    return render_template("predictions/index.html", recent_predictions=recent)


@predictions_bp.route("/predict/<int:customer_id>", methods=["GET", "POST"])
def predict_customer(customer_id):
    customer = Customer.query.get_or_404(customer_id)

    if request.method == "POST":
        features = predictor.extract_features(customer)
        probability, segment = predictor.predict(features)

        log = PredictionLog(
            customer_id=customer.id,
            model_version=predictor.model_version,
            purchase_probability=probability,
            predicted_segment=segment,
            features_used=json.dumps(features),
        )
        db.session.add(log)
        db.session.commit()

        return jsonify({
            "customer_id": customer.customer_id,
            "purchase_probability": probability,
            "predicted_segment": segment,
            "model_version": predictor.model_version,
        })

    return render_template("predictions/predict.html", customer=customer)


@predictions_bp.route("/batch", methods=["POST"])
def batch_predict():
    """Run predictions for all customers and return top candidates."""
    customers = Customer.query.all()
    results = []
    for customer in customers:
        features = predictor.extract_features(customer)
        probability, segment = predictor.predict(features)
        results.append({
            "customer_id": customer.customer_id,
            "name_placeholder": f"Customer {customer.customer_id}",
            "purchase_probability": probability,
            "predicted_segment": segment,
        })

    results.sort(key=lambda x: x["purchase_probability"], reverse=True)
    return jsonify(results[:50])  # top 50


@predictions_bp.route("/api/history/<int:customer_id>")
def prediction_history(customer_id):
    logs = PredictionLog.query.filter_by(customer_id=customer_id)\
        .order_by(PredictionLog.prediction_date.desc()).limit(10).all()
    return jsonify([log.to_dict() for log in logs])
