/* CustomerIQ – main.js */

// Live clock
function updateClock() {
  const el = document.getElementById('currentTime');
  if (el) {
    el.textContent = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  }
}
updateClock();
setInterval(updateClock, 1000);

// Sidebar toggle (mobile)
const sidebarToggle = document.getElementById('sidebarToggle');
const sidebar = document.getElementById('sidebar');
if (sidebarToggle && sidebar) {
  sidebarToggle.addEventListener('click', () => sidebar.classList.toggle('open'));
}

// Generic JSON fetch with error handling
async function fetchJSON(url) {
  const res = await fetch(url);
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  return res.json();
}

// Run batch prediction
async function runBatchPredictions(containerId) {
  const container = document.getElementById(containerId);
  if (!container) return;
  container.innerHTML = '<div class="text-center py-4"><div class="spinner-border text-indigo"></div><p class="mt-2 text-muted">Running predictions…</p></div>';
  try {
    const data = await fetchJSON('/predictions/batch');
    renderPredictionTable(container, data);
  } catch (e) {
    container.innerHTML = `<div class="alert alert-danger">Failed to load predictions: ${e.message}</div>`;
  }
}

function renderPredictionTable(container, data) {
  const rows = data.slice(0, 20).map(d => `
    <tr>
      <td><code>${d.customer_id}</code></td>
      <td><div class="progress" style="height:8px;min-width:80px">
        <div class="progress-bar bg-indigo" style="width:${(d.purchase_probability * 100).toFixed(0)}%"></div>
      </div></td>
      <td>${(d.purchase_probability * 100).toFixed(1)}%</td>
      <td><span class="seg-pill seg-${d.predicted_segment.replace(' ', '-')}">${d.predicted_segment}</span></td>
    </tr>
  `).join('');

  container.innerHTML = `
    <table class="table table-hover table-sm">
      <thead><tr><th>Customer ID</th><th>Probability</th><th>Score</th><th>Segment</th></tr></thead>
      <tbody>${rows}</tbody>
    </table>`;
}
