import pandas as pd
import numpy as np
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.colors as mcolors
import os

REPORTS_DIR = os.path.join(os.path.dirname(__file__), "..", "reports")
os.makedirs(REPORTS_DIR, exist_ok=True)

SEGMENT_COLORS = {
    "High Value": "#4f46e5",
    "Loyal": "#06b6d4",
    "At Risk": "#f59e0b",
    "New": "#10b981",
    "Churned": "#ef4444",
}


class CustomerSegmentor:
    """
    RFM-based customer segmentation with optional KMeans clustering.
    R = Recency (days since last purchase)
    F = Frequency (number of purchases)
    M = Monetary (total spend)
    """

    def __init__(self, n_clusters: int = 5):
        self.n_clusters = n_clusters
        self.scaler = StandardScaler()
        self.kmeans = KMeans(n_clusters=n_clusters, random_state=42, n_init=10)

    # ------------------------------------------------------------------
    # RFM scoring
    # ------------------------------------------------------------------

    def compute_rfm(self, df: pd.DataFrame, snapshot_date=None) -> pd.DataFrame:
        """
        df must have columns: customer_id, purchase_date, amount
        Returns a DataFrame with RFM scores per customer.
        """
        if snapshot_date is None:
            snapshot_date = df["purchase_date"].max() + pd.Timedelta(days=1)

        rfm = df.groupby("customer_id").agg(
            recency=("purchase_date", lambda x: (snapshot_date - x.max()).days),
            frequency=("purchase_date", "count"),
            monetary=("amount", "sum"),
        ).reset_index()

        # Score 1–5 (higher is better for F & M; lower recency = higher score)
        rfm["r_score"] = pd.qcut(rfm["recency"], q=5, labels=[5, 4, 3, 2, 1]).astype(int)
        rfm["f_score"] = pd.qcut(rfm["frequency"].rank(method="first"), q=5,
                                  labels=[1, 2, 3, 4, 5]).astype(int)
        rfm["m_score"] = pd.qcut(rfm["monetary"].rank(method="first"), q=5,
                                  labels=[1, 2, 3, 4, 5]).astype(int)
        rfm["rfm_score"] = rfm["r_score"] + rfm["f_score"] + rfm["m_score"]

        rfm["segment"] = rfm["rfm_score"].apply(self._score_to_segment)
        return rfm

    # ------------------------------------------------------------------
    # KMeans clustering
    # ------------------------------------------------------------------

    def fit_clusters(self, rfm: pd.DataFrame):
        features = rfm[["recency", "frequency", "monetary"]].copy()
        features_scaled = self.scaler.fit_transform(features)
        rfm["cluster"] = self.kmeans.fit_predict(features_scaled)
        return rfm

    # ------------------------------------------------------------------
    # Visualisations (saved to /reports)
    # ------------------------------------------------------------------

    def plot_segment_distribution(self, rfm: pd.DataFrame, save: bool = True) -> str:
        counts = rfm["segment"].value_counts()
        fig, ax = plt.subplots(figsize=(8, 5))
        colors = [SEGMENT_COLORS.get(s, "#6b7280") for s in counts.index]
        bars = ax.barh(counts.index, counts.values, color=colors)
        ax.bar_label(bars, padding=4, fontsize=10)
        ax.set_xlabel("Number of Customers")
        ax.set_title("Customer Segment Distribution")
        ax.spines[["top", "right"]].set_visible(False)
        plt.tight_layout()

        path = os.path.join(REPORTS_DIR, "segment_distribution.png")
        if save:
            fig.savefig(path, dpi=150, bbox_inches="tight")
        plt.close(fig)
        return path

    def plot_rfm_scatter(self, rfm: pd.DataFrame, save: bool = True) -> str:
        pca = PCA(n_components=2)
        coords = pca.fit_transform(
            self.scaler.fit_transform(rfm[["recency", "frequency", "monetary"]])
        )
        fig, ax = plt.subplots(figsize=(9, 6))
        for segment, group in rfm.assign(x=coords[:, 0], y=coords[:, 1]).groupby("segment"):
            ax.scatter(group["x"], group["y"],
                       label=segment,
                       color=SEGMENT_COLORS.get(segment, "#6b7280"),
                       alpha=0.7, s=40)
        ax.legend(title="Segment", framealpha=0.4)
        ax.set_title("Customer Clusters (PCA of RFM)")
        ax.set_xlabel("PC 1")
        ax.set_ylabel("PC 2")
        ax.spines[["top", "right"]].set_visible(False)
        plt.tight_layout()

        path = os.path.join(REPORTS_DIR, "rfm_scatter.png")
        if save:
            fig.savefig(path, dpi=150, bbox_inches="tight")
        plt.close(fig)
        return path

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _score_to_segment(score: int) -> str:
        if score >= 13:
            return "High Value"
        if score >= 10:
            return "Loyal"
        if score >= 7:
            return "At Risk"
        if score >= 4:
            return "New"
        return "Churned"
