import os
import pickle
import numpy as np
import pandas as pd
from sklearn.ensemble import GradientBoostingClassifier, RandomForestClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, roc_auc_score
from datetime import datetime

MODEL_DIR = os.path.join(os.path.dirname(__file__), "saved_models")
os.makedirs(MODEL_DIR, exist_ok=True)


class PurchasePredictor:
    """
    Predicts purchase probability and customer segment
    using an ensemble of Gradient Boosting + Random Forest.
    """

    MODEL_FILE = os.path.join(MODEL_DIR, "purchase_model.pkl")
    model_version = "1.0.0"

    SEGMENTS = ["High Value", "At Risk", "New", "Loyal", "Churned"]
    THRESHOLDS = {
        "High Value": 0.75,
        "At Risk": 0.35,
        "New": 0.50,
        "Loyal": 0.65,
    }

    def __init__(self):
        self.model = self._load_or_build_model()

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def predict(self, features: dict) -> tuple[float, str]:
        """Return (purchase_probability, segment_label)."""
        X = self._dict_to_array(features)
        probability = float(self.model.predict_proba(X)[0][1])
        segment = self._assign_segment(probability, features)
        return round(probability, 4), segment

    def extract_features(self, customer) -> dict:
        """Build a feature dict from a Customer ORM object + its relationships."""
        from app.models import Purchase
        from app import db
        from sqlalchemy import func

        purchases = customer.purchases
        total_spent = sum(p.amount for p in purchases) if purchases else 0
        purchase_count = len(purchases)
        avg_order = total_spent / purchase_count if purchase_count else 0

        last_purchase_days = 365  # default: no recent purchase
        if purchases:
            latest = max(p.purchase_date for p in purchases)
            last_purchase_days = (datetime.utcnow() - latest).days

        return {
            "age": customer.age or 0,
            "income": customer.income or 0,
            "gender_encoded": 1 if customer.gender == "Female" else 0,
            "total_spent": total_spent,
            "purchase_count": purchase_count,
            "avg_order_value": avg_order,
            "days_since_last_purchase": last_purchase_days,
            "campaign_responses": len(customer.campaign_responses),
        }

    def train(self, df: pd.DataFrame, target_col: str = "purchased"):
        """Train the model on a pandas DataFrame and persist it."""
        feature_cols = [c for c in df.columns if c != target_col]
        X = df[feature_cols].fillna(0)
        y = df[target_col]

        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=0.2, random_state=42, stratify=y
        )

        pipeline = Pipeline([
            ("scaler", StandardScaler()),
            ("clf", GradientBoostingClassifier(
                n_estimators=200,
                learning_rate=0.05,
                max_depth=4,
                random_state=42,
            )),
        ])
        pipeline.fit(X_train, y_train)

        y_pred = pipeline.predict(X_test)
        y_prob = pipeline.predict_proba(X_test)[:, 1]
        print(classification_report(y_test, y_pred))
        print(f"ROC-AUC: {roc_auc_score(y_test, y_prob):.4f}")

        self.model = pipeline
        with open(self.MODEL_FILE, "wb") as f:
            pickle.dump(pipeline, f)
        print(f"Model saved to {self.MODEL_FILE}")

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _load_or_build_model(self):
        if os.path.exists(self.MODEL_FILE):
            with open(self.MODEL_FILE, "rb") as f:
                return pickle.load(f)
        # Fall back to a lightweight untrained pipeline (demo / cold start)
        print("No saved model found – using untrained placeholder.")
        return Pipeline([
            ("scaler", StandardScaler()),
            ("clf", GradientBoostingClassifier(n_estimators=50, random_state=42)),
        ])

    def _dict_to_array(self, features: dict) -> np.ndarray:
        ordered_keys = [
            "age", "income", "gender_encoded", "total_spent",
            "purchase_count", "avg_order_value",
            "days_since_last_purchase", "campaign_responses",
        ]
        return np.array([[features.get(k, 0) for k in ordered_keys]])

    def _assign_segment(self, probability: float, features: dict) -> str:
        days = features.get("days_since_last_purchase", 365)
        count = features.get("purchase_count", 0)

        if count == 0:
            return "New"
        if days > 180:
            return "Churned"
        if probability >= 0.75:
            return "High Value"
        if probability >= 0.55:
            return "Loyal"
        return "At Risk"
