"""
scripts/train_model.py
Train and evaluate the purchase prediction model.
Usage: python scripts/train_model.py
"""
import sys
import os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

import pandas as pd
import numpy as np
from app import create_app, db
from app.models import Customer, Purchase, CampaignResponse
from ml_models.predictor import PurchasePredictor
from ml_models.segmentation import CustomerSegmentor
from datetime import datetime


def build_training_dataframe(app) -> pd.DataFrame:
    """Extract features from the database and build a labelled dataset."""
    with app.app_context():
        customers = Customer.query.all()
        records = []
        for c in customers:
            purchases = c.purchases
            total_spent = sum(p.amount for p in purchases)
            purchase_count = len(purchases)
            avg_order = total_spent / purchase_count if purchase_count else 0

            last_purchase_days = 999
            if purchases:
                latest = max(p.purchase_date for p in purchases)
                last_purchase_days = (datetime.utcnow() - latest).days

            # Label: purchased in last 90 days?
            recent = any(
                (datetime.utcnow() - p.purchase_date).days <= 90
                for p in purchases
            )

            records.append({
                "age": c.age or 0,
                "income": c.income or 0,
                "gender_encoded": 1 if c.gender == "Female" else 0,
                "total_spent": total_spent,
                "purchase_count": purchase_count,
                "avg_order_value": avg_order,
                "days_since_last_purchase": last_purchase_days,
                "campaign_responses": len(c.campaign_responses),
                "purchased": int(recent),
            })

        return pd.DataFrame(records)


def main():
    app = create_app()
    print("Building training dataset from database...")
    df = build_training_dataframe(app)
    print(f"  Dataset shape : {df.shape}")
    print(f"  Positive rate : {df['purchased'].mean():.2%}\n")

    predictor = PurchasePredictor()
    print("Training Gradient Boosting model...")
    predictor.train(df, target_col="purchased")

    print("\nRunning RFM segmentation on purchase data...")
    with app.app_context():
        rows = db.session.execute(
            db.text("SELECT customer_id, purchase_date, amount FROM purchases")
        ).fetchall()

    if rows:
        purchase_df = pd.DataFrame(rows, columns=["customer_id", "purchase_date", "amount"])
        purchase_df["purchase_date"] = pd.to_datetime(purchase_df["purchase_date"])

        segmentor = CustomerSegmentor()
        rfm = segmentor.compute_rfm(purchase_df)
        segmentor.fit_clusters(rfm)
        print(f"\nSegment distribution:\n{rfm['segment'].value_counts()}")

        dist_path = segmentor.plot_segment_distribution(rfm)
        scatter_path = segmentor.plot_rfm_scatter(rfm)
        print(f"\nCharts saved:\n  {dist_path}\n  {scatter_path}")

    print("\n✅ Training complete!")


if __name__ == "__main__":
    main()
