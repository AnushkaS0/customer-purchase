"""
scripts/seed_data.py
Populate the database with realistic synthetic data for development/demo.
Usage: python scripts/seed_data.py
"""
import sys
import os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

import random
from datetime import datetime, timedelta
from faker import Faker
from app import create_app, db
from app.models import Customer, Purchase, Campaign, CampaignResponse

fake = Faker()
random.seed(42)

SEGMENTS = ["High Value", "Loyal", "At Risk", "New", "Churned"]
CHANNELS = ["online", "in-store", "mobile"]
CATEGORIES = ["Electronics", "Clothing", "Home & Garden", "Sports", "Beauty",
               "Books", "Toys", "Food & Beverage", "Automotive", "Health"]
CAMPAIGN_TYPES = ["email", "sms", "push", "display"]


def seed_customers(n: int = 500):
    print(f"Seeding {n} customers...")
    customers = []
    for _ in range(n):
        c = Customer(
            customer_id=fake.unique.uuid4()[:12].upper(),
            age=random.randint(18, 75),
            gender=random.choice(["Male", "Female", "Other"]),
            income=round(random.uniform(20_000, 200_000), 2),
            location=fake.city(),
            segment=random.choices(SEGMENTS, weights=[15, 30, 25, 20, 10])[0],
            registration_date=fake.date_time_between(start_date="-3y", end_date="now"),
        )
        customers.append(c)
    db.session.bulk_save_objects(customers)
    db.session.commit()
    print(f"  ✓ {n} customers created")
    return Customer.query.all()


def seed_purchases(customers, avg_per_customer: int = 8):
    print("Seeding purchases...")
    purchases = []
    for customer in customers:
        n = max(0, int(random.gauss(avg_per_customer, 4)))
        for _ in range(n):
            p = Purchase(
                customer_id=customer.id,
                product_category=random.choice(CATEGORIES),
                amount=round(random.uniform(10, 1_500), 2),
                purchase_date=fake.date_time_between(start_date="-2y", end_date="now"),
                channel=random.choice(CHANNELS),
            )
            purchases.append(p)
    db.session.bulk_save_objects(purchases)
    db.session.commit()
    print(f"  ✓ {len(purchases)} purchases created")


def seed_campaigns(n: int = 15):
    print(f"Seeding {n} campaigns...")
    campaigns = []
    for i in range(n):
        start = fake.date_time_between(start_date="-1y", end_date="-30d")
        campaigns.append(Campaign(
            name=f"{fake.bs().title()} Campaign {i + 1}",
            type=random.choice(CAMPAIGN_TYPES),
            start_date=start,
            end_date=start + timedelta(days=random.randint(7, 60)),
            budget=round(random.uniform(1_000, 50_000), 2),
            target_segment=random.choice(SEGMENTS),
            status=random.choice(["active", "completed", "paused"]),
        ))
    db.session.bulk_save_objects(campaigns)
    db.session.commit()
    print(f"  ✓ {n} campaigns created")
    return Campaign.query.all()


def seed_campaign_responses(customers, campaigns):
    print("Seeding campaign responses...")
    responses = []
    for campaign in campaigns:
        sample_size = random.randint(50, min(200, len(customers)))
        sample = random.sample(customers, sample_size)
        for customer in sample:
            converted = random.random() < 0.20  # 20% base conversion
            responses.append(CampaignResponse(
                campaign_id=campaign.id,
                customer_id=customer.id,
                response_date=campaign.start_date + timedelta(days=random.randint(0, 30)),
                converted=converted,
                revenue_generated=round(random.uniform(20, 500), 2) if converted else 0.0,
            ))
    db.session.bulk_save_objects(responses)
    db.session.commit()
    print(f"  ✓ {len(responses)} campaign responses created")


def main():
    app = create_app()
    with app.app_context():
        print("Dropping and recreating all tables...")
        db.drop_all()
        db.create_all()

        customers = seed_customers(500)
        seed_purchases(customers)
        campaigns = seed_campaigns(15)
        seed_campaign_responses(customers, campaigns)

        print("\n✅ Database seeded successfully!")
        print(f"   Customers : {Customer.query.count()}")
        print(f"   Purchases : {Purchase.query.count()}")
        print(f"   Campaigns : {Campaign.query.count()}")
        print(f"   Responses : {CampaignResponse.query.count()}")


if __name__ == "__main__":
    main()
