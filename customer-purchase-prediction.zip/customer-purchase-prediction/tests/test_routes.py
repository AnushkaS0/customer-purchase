"""
tests/test_routes.py – Basic route and API tests.
Run with: pytest tests/ -v
"""
import pytest
import json
from app import create_app, db


@pytest.fixture(scope="module")
def app():
    app = create_app()
    app.config.update({
        "TESTING": True,
        "SQLALCHEMY_DATABASE_URI": "sqlite:///:memory:",
        "WTF_CSRF_ENABLED": False,
    })
    with app.app_context():
        db.create_all()
        yield app
        db.drop_all()


@pytest.fixture
def client(app):
    return app.test_client()


# ------------------------------------------------------------------
# Main routes
# ------------------------------------------------------------------

def test_index(client):
    res = client.get("/")
    assert res.status_code == 200
    assert b"CustomerIQ" in res.data


def test_dashboard(client):
    res = client.get("/dashboard")
    assert res.status_code == 200


# ------------------------------------------------------------------
# Customer routes
# ------------------------------------------------------------------

def test_customer_list(client):
    res = client.get("/customers/")
    assert res.status_code == 200


def test_customer_segment_api(client):
    res = client.get("/customers/api/segments")
    assert res.status_code == 200
    data = json.loads(res.data)
    assert isinstance(data, list)


def test_customer_api_list(client):
    res = client.get("/customers/api/list")
    assert res.status_code == 200


# ------------------------------------------------------------------
# Campaign routes
# ------------------------------------------------------------------

def test_campaigns_list(client):
    res = client.get("/campaigns/")
    assert res.status_code == 200


def test_campaigns_performance_api(client):
    res = client.get("/campaigns/api/performance")
    assert res.status_code == 200


def test_campaigns_roi_api(client):
    res = client.get("/campaigns/api/roi")
    assert res.status_code == 200


# ------------------------------------------------------------------
# Analytics routes
# ------------------------------------------------------------------

def test_analytics_home(client):
    res = client.get("/analytics/")
    assert res.status_code == 200


def test_revenue_trend_api(client):
    res = client.get("/analytics/api/revenue-trend")
    assert res.status_code == 200
    assert isinstance(json.loads(res.data), list)


def test_channel_breakdown_api(client):
    res = client.get("/analytics/api/channel-breakdown")
    assert res.status_code == 200


def test_category_performance_api(client):
    res = client.get("/analytics/api/category-performance")
    assert res.status_code == 200


# ------------------------------------------------------------------
# Predictions routes
# ------------------------------------------------------------------

def test_predictions_home(client):
    res = client.get("/predictions/")
    assert res.status_code == 200


def test_batch_predict(client):
    res = client.post("/predictions/batch")
    assert res.status_code == 200
    data = json.loads(res.data)
    assert isinstance(data, list)
