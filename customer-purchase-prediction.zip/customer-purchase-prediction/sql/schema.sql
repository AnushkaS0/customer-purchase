-- ============================================================
-- Customer Purchase Prediction & Campaign Analytics
-- MySQL Schema
-- ============================================================

CREATE DATABASE IF NOT EXISTS customer_analytics
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE customer_analytics;

-- ------------------------------------------------------------
-- customers
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS customers (
    id               INT AUTO_INCREMENT PRIMARY KEY,
    customer_id      VARCHAR(50)  NOT NULL UNIQUE,
    age              INT,
    gender           VARCHAR(10),
    income           DECIMAL(12, 2),
    location         VARCHAR(100),
    segment          VARCHAR(50),
    registration_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_segment (segment),
    INDEX idx_registration_date (registration_date)
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- purchases
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS purchases (
    id               INT AUTO_INCREMENT PRIMARY KEY,
    customer_id      INT NOT NULL,
    product_category VARCHAR(100),
    amount           DECIMAL(10, 2) NOT NULL,
    purchase_date    DATETIME DEFAULT CURRENT_TIMESTAMP,
    channel          VARCHAR(50),
    FOREIGN KEY (customer_id) REFERENCES customers(id) ON DELETE CASCADE,
    INDEX idx_customer (customer_id),
    INDEX idx_purchase_date (purchase_date),
    INDEX idx_channel (channel)
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- campaigns
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS campaigns (
    id               INT AUTO_INCREMENT PRIMARY KEY,
    name             VARCHAR(200) NOT NULL,
    type             VARCHAR(50),
    start_date       DATETIME,
    end_date         DATETIME,
    budget           DECIMAL(12, 2),
    target_segment   VARCHAR(50),
    status           VARCHAR(20) DEFAULT 'active',
    INDEX idx_status (status),
    INDEX idx_type (type)
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- campaign_responses
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS campaign_responses (
    id                 INT AUTO_INCREMENT PRIMARY KEY,
    campaign_id        INT NOT NULL,
    customer_id        INT NOT NULL,
    response_date      DATETIME DEFAULT CURRENT_TIMESTAMP,
    converted          TINYINT(1) DEFAULT 0,
    revenue_generated  DECIMAL(10, 2) DEFAULT 0.00,
    FOREIGN KEY (campaign_id) REFERENCES campaigns(id) ON DELETE CASCADE,
    FOREIGN KEY (customer_id) REFERENCES customers(id) ON DELETE CASCADE,
    INDEX idx_campaign (campaign_id),
    INDEX idx_customer (customer_id),
    INDEX idx_converted (converted)
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- prediction_logs
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS prediction_logs (
    id                    INT AUTO_INCREMENT PRIMARY KEY,
    customer_id           INT NOT NULL,
    model_version         VARCHAR(50),
    purchase_probability  FLOAT,
    predicted_segment     VARCHAR(50),
    prediction_date       DATETIME DEFAULT CURRENT_TIMESTAMP,
    features_used         TEXT,
    FOREIGN KEY (customer_id) REFERENCES customers(id) ON DELETE CASCADE,
    INDEX idx_customer (customer_id),
    INDEX idx_prediction_date (prediction_date)
) ENGINE=InnoDB;
