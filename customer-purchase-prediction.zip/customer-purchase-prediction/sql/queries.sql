-- ============================================================
-- Analytical Queries – Customer Purchase Prediction & Analytics
-- ============================================================

USE customer_analytics;

-- ------------------------------------------------------------
-- 1. RFM scores for every customer
-- ------------------------------------------------------------
SELECT
    c.customer_id,
    c.segment,
    DATEDIFF(NOW(), MAX(p.purchase_date))        AS recency_days,
    COUNT(p.id)                                  AS frequency,
    ROUND(SUM(p.amount), 2)                      AS monetary
FROM customers c
LEFT JOIN purchases p ON p.customer_id = c.id
GROUP BY c.id, c.customer_id, c.segment
ORDER BY monetary DESC;

-- ------------------------------------------------------------
-- 2. Monthly revenue trend
-- ------------------------------------------------------------
SELECT
    DATE_FORMAT(purchase_date, '%Y-%m')          AS period,
    COUNT(*)                                     AS transactions,
    ROUND(SUM(amount), 2)                        AS revenue,
    ROUND(AVG(amount), 2)                        AS avg_order_value
FROM purchases
GROUP BY period
ORDER BY period;

-- ------------------------------------------------------------
-- 3. Campaign performance summary
-- ------------------------------------------------------------
SELECT
    ca.name                                                   AS campaign,
    ca.type,
    ca.budget,
    COUNT(cr.id)                                              AS total_responses,
    SUM(cr.converted)                                         AS conversions,
    ROUND(SUM(cr.converted) / COUNT(cr.id) * 100, 2)         AS conversion_rate_pct,
    ROUND(SUM(cr.revenue_generated), 2)                       AS revenue,
    ROUND(
        (SUM(cr.revenue_generated) - ca.budget) / ca.budget * 100, 2
    )                                                         AS roi_pct
FROM campaigns ca
LEFT JOIN campaign_responses cr ON cr.campaign_id = ca.id
GROUP BY ca.id, ca.name, ca.type, ca.budget
ORDER BY roi_pct DESC;

-- ------------------------------------------------------------
-- 4. Top customers by lifetime value
-- ------------------------------------------------------------
SELECT
    c.customer_id,
    c.segment,
    c.age,
    c.location,
    ROUND(SUM(p.amount), 2)    AS lifetime_value,
    COUNT(p.id)                AS total_purchases,
    ROUND(AVG(p.amount), 2)    AS avg_order_value,
    MAX(p.purchase_date)       AS last_purchase_date
FROM customers c
JOIN purchases p ON p.customer_id = c.id
GROUP BY c.id, c.customer_id, c.segment, c.age, c.location
ORDER BY lifetime_value DESC
LIMIT 50;

-- ------------------------------------------------------------
-- 5. Product category performance
-- ------------------------------------------------------------
SELECT
    product_category,
    COUNT(*)                   AS orders,
    ROUND(SUM(amount), 2)      AS total_revenue,
    ROUND(AVG(amount), 2)      AS avg_order_value,
    COUNT(DISTINCT customer_id) AS unique_customers
FROM purchases
GROUP BY product_category
ORDER BY total_revenue DESC;

-- ------------------------------------------------------------
-- 6. Channel attribution
-- ------------------------------------------------------------
SELECT
    channel,
    COUNT(*)                   AS orders,
    ROUND(SUM(amount), 2)      AS revenue,
    ROUND(AVG(amount), 2)      AS avg_order,
    COUNT(DISTINCT customer_id) AS unique_customers
FROM purchases
GROUP BY channel;

-- ------------------------------------------------------------
-- 7. At-risk customers (purchased before but silent 90+ days)
-- ------------------------------------------------------------
SELECT
    c.customer_id,
    c.segment,
    MAX(p.purchase_date)        AS last_purchase,
    DATEDIFF(NOW(), MAX(p.purchase_date)) AS days_inactive,
    ROUND(SUM(p.amount), 2)    AS lifetime_value
FROM customers c
JOIN purchases p ON p.customer_id = c.id
GROUP BY c.id, c.customer_id, c.segment
HAVING days_inactive >= 90
ORDER BY lifetime_value DESC;

-- ------------------------------------------------------------
-- 8. Segment conversion rates across campaigns
-- ------------------------------------------------------------
SELECT
    ca.target_segment,
    COUNT(cr.id)                                           AS total_reached,
    SUM(cr.converted)                                      AS converted,
    ROUND(SUM(cr.converted) / COUNT(cr.id) * 100, 2)      AS conversion_rate_pct
FROM campaigns ca
JOIN campaign_responses cr ON cr.campaign_id = ca.id
GROUP BY ca.target_segment
ORDER BY conversion_rate_pct DESC;
